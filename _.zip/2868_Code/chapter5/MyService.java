public class MyService {
    public String sayHello(String name) {
        return "Hello " + name;
    }

    public int add(int a, int b) {
        return a + b;
    }
}